"""
GPU-ACCELERATED MULTI-HOP ARBITRAGE ROUTER
Uses CUDA to calculate optimal arbitrage routes across multiple DEX hops
"""

import json
import numpy as np
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
import time

try:
    import cupy as cp
    GPU_AVAILABLE = True
    print("✓ CuPy (CUDA) detected - GPU acceleration enabled")
except ImportError:
    import numpy as cp
    GPU_AVAILABLE = False
    print("⚠️  CuPy not found - using CPU fallback (slower)")


@dataclass
class MultiHopRoute:
    """Multi-hop arbitrage route"""
    path: List[str]  # ['SOL', 'USDC', 'RAY', 'SOL']
    dexes: List[str]  # ['Raydium', 'Orca', 'Meteora']
    prices: List[float]
    fees: List[float]
    net_profit_pct: float
    gross_profit_pct: float
    min_liquidity: float
    execution_risk: float
    confidence: float
    
    def __str__(self):
        route_str = " → ".join([f"{self.path[i]} ({self.dexes[i]})" for i in range(len(self.dexes))])
        route_str += f" → {self.path[-1]}"
        return route_str


class GPUArbitrageRouter:
    """GPU-accelerated multi-hop arbitrage pathfinding"""
    
    def __init__(self, max_hops: int = 4, min_profit_pct: float = 0.01):
        self.max_hops = max_hops
        self.min_profit_pct = min_profit_pct
        self.pools: List[Dict] = []
        self.tokens: List[str] = []
        self.token_to_idx: Dict[str, int] = {}
        
        # GPU matrices
        self.price_matrix = None
        self.liquidity_matrix = None
        self.fee_matrix = None
        self.dex_matrix = None
        
    def load_pools(self, filename: str = "pools_for_gpu.json"):
        """Load pool data from price tracker"""
        with open(filename, 'r') as f:
            data = json.load(f)
        
        self.pools = data['pools']
        
        # Extract unique tokens
        token_set = set()
        for pool in self.pools:
            token_set.add(pool['token_a'])
            token_set.add(pool['token_b'])
        
        self.tokens = sorted(list(token_set))
        self.token_to_idx = {token: i for i, token in enumerate(self.tokens)}
        
        print(f"✓ Loaded {len(self.pools)} pools with {len(self.tokens)} tokens")
        return len(self.pools)
    
    def build_gpu_matrices(self):
        """Build GPU-optimized adjacency matrices"""
        n = len(self.tokens)
        
        # Initialize matrices (on CPU first)
        price_matrix = np.zeros((n, n), dtype=np.float32)
        liquidity_matrix = np.zeros((n, n), dtype=np.float32)
        fee_matrix = np.ones((n, n), dtype=np.float32) * 999.0  # High default fee
        dex_matrix = np.zeros((n, n), dtype=np.int32) - 1  # -1 = no connection
        
        # DEX name to ID mapping
        dex_names = {}
        dex_id = 0
        
        # Fill matrices with pool data
        for pool in self.pools:
            token_a = pool['token_a']
            token_b = pool['token_b']
            
            if token_a not in self.token_to_idx or token_b not in self.token_to_idx:
                continue
            
            i = self.token_to_idx[token_a]
            j = self.token_to_idx[token_b]
            
            price = pool['price']
            liquidity = pool['liquidity_usd']
            fee = pool['fee_rate']
            dex = pool['dex']
            
            # Assign DEX ID
            if dex not in dex_names:
                dex_names[dex] = dex_id
                dex_id += 1
            
            # Only keep best (highest liquidity) pool for each token pair
            if liquidity > liquidity_matrix[i, j]:
                # A → B
                price_matrix[i, j] = price
                liquidity_matrix[i, j] = liquidity
                fee_matrix[i, j] = fee
                dex_matrix[i, j] = dex_names[dex]
                
                # B → A (inverse)
                if price > 0:
                    price_matrix[j, i] = 1.0 / price
                    liquidity_matrix[j, i] = liquidity
                    fee_matrix[j, i] = fee
                    dex_matrix[j, i] = dex_names[dex]
        
        # Transfer to GPU
        self.price_matrix = cp.array(price_matrix)
        self.liquidity_matrix = cp.array(liquidity_matrix)
        self.fee_matrix = cp.array(fee_matrix)
        self.dex_matrix = cp.array(dex_matrix)
        
        self.dex_id_to_name = {v: k for k, v in dex_names.items()}
        
        # Count valid connections
        valid_connections = int(cp.sum(self.dex_matrix >= 0))
        print(f"✓ Built GPU matrices: {n}x{n} with {valid_connections} valid trading pairs")
        print(f"  DEXes: {list(dex_names.keys())}")
    
    def find_2hop_routes_gpu(self, start_token: str) -> List[MultiHopRoute]:
        """Find 2-hop arbitrage routes using GPU"""
        if start_token not in self.token_to_idx:
            return []
        
        start_idx = self.token_to_idx[start_token]
        n = len(self.tokens)
        routes = []
        
        # GPU computation: start → intermediate → start
        # Get all valid first hops
        first_hop_mask = self.dex_matrix[start_idx, :] >= 0
        intermediate_indices = cp.where(first_hop_mask)[0]
        
        for mid_idx in intermediate_indices:
            mid_idx = int(mid_idx)
            
            # Check second hop back to start
            if self.dex_matrix[mid_idx, start_idx] >= 0:
                # Calculate profit
                price1 = float(self.price_matrix[start_idx, mid_idx])
                price2 = float(self.price_matrix[mid_idx, start_idx])
                fee1 = float(self.fee_matrix[start_idx, mid_idx])
                fee2 = float(self.fee_matrix[mid_idx, start_idx])
                
                # Net return after fees
                net_return = price1 * price2 * (1 - fee1) * (1 - fee2)
                profit_pct = (net_return - 1.0) * 100
                
                if profit_pct > self.min_profit_pct * 100:
                    liq1 = float(self.liquidity_matrix[start_idx, mid_idx])
                    liq2 = float(self.liquidity_matrix[mid_idx, start_idx])
                    
                    dex1_id = int(self.dex_matrix[start_idx, mid_idx])
                    dex2_id = int(self.dex_matrix[mid_idx, start_idx])
                    
                    route = MultiHopRoute(
                        path=[start_token, self.tokens[mid_idx], start_token],
                        dexes=[self.dex_id_to_name[dex1_id], self.dex_id_to_name[dex2_id]],
                        prices=[price1, price2],
                        fees=[fee1, fee2],
                        net_profit_pct=profit_pct,
                        gross_profit_pct=(price1 * price2 - 1.0) * 100,
                        min_liquidity=min(liq1, liq2),
                        execution_risk=1.0 / min(liq1, liq2) * 10000,  # Lower liquidity = higher risk
                        confidence=0.9 if min(liq1, liq2) > 50000 else 0.7
                    )
                    routes.append(route)
        
        return sorted(routes, key=lambda x: x.net_profit_pct, reverse=True)
    
    def find_3hop_routes_gpu(self, start_token: str) -> List[MultiHopRoute]:
        """Find 3-hop arbitrage routes using GPU matrix multiplication"""
        if start_token not in self.token_to_idx:
            return []
        
        start_idx = self.token_to_idx[start_token]
        n = len(self.tokens)
        routes = []
        
        # Find all 3-hop paths: start → A → B → start
        first_hop_mask = self.dex_matrix[start_idx, :] >= 0
        first_hop_indices = cp.where(first_hop_mask)[0]
        
        for idx_a in first_hop_indices:
            idx_a = int(idx_a)
            
            second_hop_mask = self.dex_matrix[idx_a, :] >= 0
            second_hop_indices = cp.where(second_hop_mask)[0]
            
            for idx_b in second_hop_indices:
                idx_b = int(idx_b)
                
                # Check if we can return to start
                if idx_b != start_idx and self.dex_matrix[idx_b, start_idx] >= 0:
                    # Calculate 3-hop profit
                    p1 = float(self.price_matrix[start_idx, idx_a])
                    p2 = float(self.price_matrix[idx_a, idx_b])
                    p3 = float(self.price_matrix[idx_b, start_idx])
                    
                    f1 = float(self.fee_matrix[start_idx, idx_a])
                    f2 = float(self.fee_matrix[idx_a, idx_b])
                    f3 = float(self.fee_matrix[idx_b, start_idx])
                    
                    net_return = p1 * p2 * p3 * (1 - f1) * (1 - f2) * (1 - f3)
                    profit_pct = (net_return - 1.0) * 100
                    
                    if profit_pct > self.min_profit_pct * 100:
                        l1 = float(self.liquidity_matrix[start_idx, idx_a])
                        l2 = float(self.liquidity_matrix[idx_a, idx_b])
                        l3 = float(self.liquidity_matrix[idx_b, start_idx])
                        
                        d1 = int(self.dex_matrix[start_idx, idx_a])
                        d2 = int(self.dex_matrix[idx_a, idx_b])
                        d3 = int(self.dex_matrix[idx_b, start_idx])
                        
                        route = MultiHopRoute(
                            path=[start_token, self.tokens[idx_a], self.tokens[idx_b], start_token],
                            dexes=[self.dex_id_to_name[d1], self.dex_id_to_name[d2], self.dex_id_to_name[d3]],
                            prices=[p1, p2, p3],
                            fees=[f1, f2, f3],
                            net_profit_pct=profit_pct,
                            gross_profit_pct=(p1 * p2 * p3 - 1.0) * 100,
                            min_liquidity=min(l1, l2, l3),
                            execution_risk=3.0 / min(l1, l2, l3) * 10000,
                            confidence=0.8 if min(l1, l2, l3) > 50000 else 0.6
                        )
                        routes.append(route)
        
        return sorted(routes, key=lambda x: x.net_profit_pct, reverse=True)
    
    def find_4hop_routes_gpu(self, start_token: str, max_routes: int = 100) -> List[MultiHopRoute]:
        """Find 4-hop routes (most complex, highest potential profit)"""
        if start_token not in self.token_to_idx:
            return []
        
        start_idx = self.token_to_idx[start_token]
        routes = []
        
        # 4-hop: start → A → B → C → start
        first_hops = cp.where(self.dex_matrix[start_idx, :] >= 0)[0]
        
        for idx_a in first_hops:
            idx_a = int(idx_a)
            second_hops = cp.where(self.dex_matrix[idx_a, :] >= 0)[0]
            
            for idx_b in second_hops:
                idx_b = int(idx_b)
                if idx_b == start_idx:
                    continue
                
                third_hops = cp.where(self.dex_matrix[idx_b, :] >= 0)[0]
                
                for idx_c in third_hops:
                    idx_c = int(idx_c)
                    if idx_c == start_idx or idx_c == idx_a:
                        continue
                    
                    # Check final hop back
                    if self.dex_matrix[idx_c, start_idx] >= 0:
                        # Calculate profit
                        p1 = float(self.price_matrix[start_idx, idx_a])
                        p2 = float(self.price_matrix[idx_a, idx_b])
                        p3 = float(self.price_matrix[idx_b, idx_c])
                        p4 = float(self.price_matrix[idx_c, start_idx])
                        
                        f1 = float(self.fee_matrix[start_idx, idx_a])
                        f2 = float(self.fee_matrix[idx_a, idx_b])
                        f3 = float(self.fee_matrix[idx_b, idx_c])
                        f4 = float(self.fee_matrix[idx_c, start_idx])
                        
                        net_return = p1 * p2 * p3 * p4 * (1-f1) * (1-f2) * (1-f3) * (1-f4)
                        profit_pct = (net_return - 1.0) * 100
                        
                        if profit_pct > self.min_profit_pct * 100:
                            l1 = float(self.liquidity_matrix[start_idx, idx_a])
                            l2 = float(self.liquidity_matrix[idx_a, idx_b])
                            l3 = float(self.liquidity_matrix[idx_b, idx_c])
                            l4 = float(self.liquidity_matrix[idx_c, start_idx])
                            
                            d1 = int(self.dex_matrix[start_idx, idx_a])
                            d2 = int(self.dex_matrix[idx_a, idx_b])
                            d3 = int(self.dex_matrix[idx_b, idx_c])
                            d4 = int(self.dex_matrix[idx_c, start_idx])
                            
                            route = MultiHopRoute(
                                path=[start_token, self.tokens[idx_a], self.tokens[idx_b], 
                                     self.tokens[idx_c], start_token],
                                dexes=[self.dex_id_to_name[d1], self.dex_id_to_name[d2],
                                      self.dex_id_to_name[d3], self.dex_id_to_name[d4]],
                                prices=[p1, p2, p3, p4],
                                fees=[f1, f2, f3, f4],
                                net_profit_pct=profit_pct,
                                gross_profit_pct=(p1*p2*p3*p4 - 1.0) * 100,
                                min_liquidity=min(l1, l2, l3, l4),
                                execution_risk=4.0 / min(l1, l2, l3, l4) * 10000,
                                confidence=0.7 if min(l1, l2, l3, l4) > 50000 else 0.5
                            )
                            routes.append(route)
                            
                            # Limit routes to prevent memory issues
                            if len(routes) >= max_routes:
                                return sorted(routes, key=lambda x: x.net_profit_pct, reverse=True)
        
        return sorted(routes, key=lambda x: x.net_profit_pct, reverse=True)
    
    def find_all_routes(self, start_token: str = 'SOL', top_n: int = 20) -> Dict[str, List[MultiHopRoute]]:
        """Find all profitable multi-hop routes"""
        print(f"\n🔍 Searching for multi-hop arbitrage routes starting from {start_token}...")
        print("="*80)
        
        results = {}
        
        # 2-hop routes (fastest, lowest risk)
        print("Calculating 2-hop routes...")
        start = time.time()
        routes_2hop = self.find_2hop_routes_gpu(start_token)
        time_2hop = time.time() - start
        print(f"✓ Found {len(routes_2hop)} 2-hop routes in {time_2hop:.3f}s")
        results['2-hop'] = routes_2hop[:top_n]
        
        # 3-hop routes (balanced)
        print("Calculating 3-hop routes...")
        start = time.time()
        routes_3hop = self.find_3hop_routes_gpu(start_token)
        time_3hop = time.time() - start
        print(f"✓ Found {len(routes_3hop)} 3-hop routes in {time_3hop:.3f}s")
        results['3-hop'] = routes_3hop[:top_n]
        
        # 4-hop routes (highest profit potential, highest risk)
        if self.max_hops >= 4:
            print("Calculating 4-hop routes...")
            start = time.time()
            routes_4hop = self.find_4hop_routes_gpu(start_token, max_routes=100)
            time_4hop = time.time() - start
            print(f"✓ Found {len(routes_4hop)} 4-hop routes in {time_4hop:.3f}s")
            results['4-hop'] = routes_4hop[:top_n]
        
        return results
    
    def display_routes(self, results: Dict[str, List[MultiHopRoute]]):
        """Display best multi-hop routes"""
        print("\n" + "="*80)
        print("🎯 BEST MULTI-HOP ARBITRAGE ROUTES")
        print("="*80)
        
        for hop_type, routes in results.items():
            if not routes:
                continue
            
            print(f"\n{hop_type.upper()} ROUTES:")
            print("-" * 80)
            
            for i, route in enumerate(routes[:10], 1):
                print(f"\n{i}. Net Profit: {route.net_profit_pct:.3f}% | " +
                      f"Confidence: {route.confidence:.0%} | " +
                      f"Min Liq: ${route.min_liquidity:,.0f}")
                print(f"   Route: {route}")
                print(f"   Fees: {sum(route.fees)*100:.2f}% total | " +
                      f"Gross: {route.gross_profit_pct:.3f}%")
    
    def export_routes(self, results: Dict[str, List[MultiHopRoute]], 
                     filename: str = "multihop_routes.json"):
        """Export routes to JSON for execution"""
        output = {
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'gpu_enabled': GPU_AVAILABLE,
            'routes': {}
        }
        
        for hop_type, routes in results.items():
            output['routes'][hop_type] = [
                {
                    'path': route.path,
                    'dexes': route.dexes,
                    'prices': route.prices,
                    'fees': route.fees,
                    'net_profit_pct': route.net_profit_pct,
                    'gross_profit_pct': route.gross_profit_pct,
                    'min_liquidity': route.min_liquidity,
                    'confidence': route.confidence,
                    'execution_risk': route.execution_risk
                }
                for route in routes
            ]
        
        with open(filename, 'w') as f:
            json.dump(output, f, indent=2)
        
        print(f"\n✓ Exported routes to {filename}")


def main():
    print("="*80)
    print("GPU-ACCELERATED MULTI-HOP ARBITRAGE ROUTER")
    print("="*80)
    
    # Initialize router
    router = GPUArbitrageRouter(max_hops=4, min_profit_pct=0.005)  # 0.5% minimum profit
    
    # Load pool data from price tracker
    try:
        router.load_pools("pools_for_gpu.json")
    except FileNotFoundError:
        print("❌ Error: pools_for_gpu.json not found!")
        print("   Run multi_dex_prices_realistic.py first to generate pool data")
        return
    
    # Build GPU matrices
    router.build_gpu_matrices()
    
    # Find all routes
    results = router.find_all_routes(start_token='SOL', top_n=20)
    
    # Display and export
    router.display_routes(results)
    router.export_routes(results)
    
    print("\n" + "="*80)
    print("✓ Multi-hop route analysis complete!")
    print("="*80)


if __name__ == "__main__":
    main()
