"""
VOLATILITY DETECTOR
Analyseert arbitrage kansen en bepaalt of GPU multi-hop analysis nodig is
"""

import json
from datetime import datetime
from typing import Dict, List, Tuple
from dataclasses import dataclass


@dataclass
class VolatilitySignal:
    """Signal indicating GPU should be activated"""
    triggered: bool
    reason: str
    opportunity_count: int
    best_spread_pct: float
    total_potential_profit_eur: float
    high_confidence_count: int
    timestamp: str
    details: List[Dict]


class VolatilityDetector:
    """Detects when market conditions warrant GPU analysis"""
    
    def __init__(self, config: Dict = None):
        # Default thresholds (conservative for 250 EUR test capital)
        self.config = config or {
            'min_opportunities': 2,              # Minimaal 2 kansen
            'min_spread_pct': 0.8,              # Minimaal 0.8% spread
            'min_confidence': 0.70,              # Minimaal 70% confidence
            'min_liquidity': 50000,              # Minimaal $50k liquidity
            'min_potential_profit_eur': 5.0,    # Minimaal €5 potentiële winst
            'test_capital_eur': 250,             # Test inleg
            'safety_margin': 0.3                 # 30% safety margin voor slippage/fees
        }
    
    def analyze_opportunities(self, opportunities: List[Dict]) -> VolatilitySignal:
        """
        Analyze arbitrage opportunities and determine if GPU should be activated
        
        Args:
            opportunities: List of arbitrage opportunities from price tracker
            
        Returns:
            VolatilitySignal with decision and details
        """
        if not opportunities:
            return VolatilitySignal(
                triggered=False,
                reason="No opportunities detected",
                opportunity_count=0,
                best_spread_pct=0.0,
                total_potential_profit_eur=0.0,
                high_confidence_count=0,
                timestamp=datetime.now().isoformat(),
                details=[]
            )
        
        # Filter high-quality opportunities
        high_quality_opps = self._filter_high_quality(opportunities)
        
        if not high_quality_opps:
            return VolatilitySignal(
                triggered=False,
                reason="No high-quality opportunities (filtered by confidence/liquidity)",
                opportunity_count=len(opportunities),
                best_spread_pct=max([o.get('spread_pct', 0) for o in opportunities]),
                total_potential_profit_eur=0.0,
                high_confidence_count=0,
                timestamp=datetime.now().isoformat(),
                details=[]
            )
        
        # Calculate metrics
        best_spread = max([o['spread_pct'] for o in high_quality_opps])
        total_profit = self._calculate_total_profit(high_quality_opps)
        
        # Decision logic
        triggered = (
            len(high_quality_opps) >= self.config['min_opportunities'] and
            best_spread >= self.config['min_spread_pct'] and
            total_profit >= self.config['min_potential_profit_eur']
        )
        
        reason = self._generate_reason(triggered, high_quality_opps, best_spread, total_profit)
        
        return VolatilitySignal(
            triggered=triggered,
            reason=reason,
            opportunity_count=len(high_quality_opps),
            best_spread_pct=best_spread,
            total_potential_profit_eur=total_profit,
            high_confidence_count=len([o for o in high_quality_opps if o['confidence_score'] >= 0.8]),
            timestamp=datetime.now().isoformat(),
            details=high_quality_opps
        )
    
    def _filter_high_quality(self, opportunities: List[Dict]) -> List[Dict]:
        """Filter opportunities by quality thresholds"""
        filtered = []
        
        for opp in opportunities:
            if (opp.get('confidence_score', 0) >= self.config['min_confidence'] and
                opp.get('spread_pct', 0) >= self.config['min_spread_pct'] and
                min(opp.get('buy_liquidity', 0), opp.get('sell_liquidity', 0)) >= self.config['min_liquidity']):
                filtered.append(opp)
        
        return filtered
    
    def _calculate_total_profit(self, opportunities: List[Dict]) -> float:
        """
        Calculate realistic total profit potential with test capital
        
        Assumes equal capital split across opportunities
        """
        if not opportunities:
            return 0.0
        
        capital_per_trade = self.config['test_capital_eur'] / len(opportunities)
        total_profit = 0.0
        
        for opp in opportunities:
            # Calculate trade size based on liquidity constraint
            max_tokens = opp.get('max_trade_size', 0)
            buy_price = opp.get('buy_price', 0)
            
            # EUR to tokens (assuming SOL ~€200, adjust for other tokens)
            estimated_token_price_eur = buy_price * 0.85  # Rough EUR conversion
            max_tokens_affordable = capital_per_trade / estimated_token_price_eur
            
            # Take minimum (liquidity constrained or capital constrained)
            trade_size = min(max_tokens, max_tokens_affordable)
            
            # Calculate profit
            profit_per_token = opp.get('profit_per_token', 0)
            gross_profit_eur = trade_size * profit_per_token * 0.85  # EUR conversion
            
            # Apply safety margin for slippage, fees, execution risk
            net_profit = gross_profit_eur * (1 - self.config['safety_margin'])
            
            total_profit += net_profit
        
        return round(total_profit, 2)
    
    def _generate_reason(self, triggered: bool, opportunities: List[Dict], 
                        best_spread: float, total_profit: float) -> str:
        """Generate human-readable reason for decision"""
        if triggered:
            return (f"🚀 GPU TRIGGERED: {len(opportunities)} opportunities detected | "
                   f"Best spread: {best_spread:.2f}% | "
                   f"Potential profit: €{total_profit:.2f}")
        else:
            reasons = []
            if len(opportunities) < self.config['min_opportunities']:
                reasons.append(f"Only {len(opportunities)} opportunities (need {self.config['min_opportunities']})")
            if best_spread < self.config['min_spread_pct']:
                reasons.append(f"Best spread {best_spread:.2f}% < {self.config['min_spread_pct']}%")
            if total_profit < self.config['min_potential_profit_eur']:
                reasons.append(f"Profit €{total_profit:.2f} < €{self.config['min_potential_profit_eur']}")
            
            return "⏸️  GPU NOT TRIGGERED: " + " | ".join(reasons)
    
    def load_from_file(self, filename: str = "realistic_arbitrage.json") -> VolatilitySignal:
        """Load opportunities from price tracker output and analyze"""
        try:
            with open(filename, 'r') as f:
                data = json.load(f)
            
            opportunities = data.get('opportunities', [])
            return self.analyze_opportunities(opportunities)
        
        except FileNotFoundError:
            return VolatilitySignal(
                triggered=False,
                reason=f"File {filename} not found - is price tracker running?",
                opportunity_count=0,
                best_spread_pct=0.0,
                total_potential_profit_eur=0.0,
                high_confidence_count=0,
                timestamp=datetime.now().isoformat(),
                details=[]
            )
        except Exception as e:
            return VolatilitySignal(
                triggered=False,
                reason=f"Error reading {filename}: {str(e)}",
                opportunity_count=0,
                best_spread_pct=0.0,
                total_potential_profit_eur=0.0,
                high_confidence_count=0,
                timestamp=datetime.now().isoformat(),
                details=[]
            )


def main():
    """Test volatility detector"""
    print("VOLATILITY DETECTOR TEST")
    print("="*80)
    
    # Initialize detector with test capital config
    detector = VolatilityDetector(config={
        'min_opportunities': 2,
        'min_spread_pct': 0.8,
        'min_confidence': 0.70,
        'min_liquidity': 50000,
        'min_potential_profit_eur': 5.0,
        'test_capital_eur': 250,
        'safety_margin': 0.3
    })
    
    # Analyze current opportunities
    signal = detector.load_from_file("realistic_arbitrage.json")
    
    print(f"\n{signal.reason}")
    print(f"Timestamp: {signal.timestamp}")
    print(f"Opportunities: {signal.opportunity_count}")
    print(f"Best spread: {signal.best_spread_pct:.2f}%")
    print(f"Potential profit: €{signal.total_potential_profit_eur:.2f}")
    print(f"High confidence count: {signal.high_confidence_count}")
    
    if signal.triggered:
        print("\n🎯 TOP OPPORTUNITIES:")
        for i, opp in enumerate(signal.details[:5], 1):
            print(f"\n{i}. {opp['token']}")
            print(f"   Spread: {opp['spread_pct']:.2f}% | Confidence: {opp['confidence_score']:.0%}")
            print(f"   {opp['buy_dex']} → {opp['sell_dex']}")
            print(f"   Max size: {opp['max_trade_size']:.2f} tokens")
    
    print("\n" + "="*80)
    
    return signal.triggered


if __name__ == "__main__":
    triggered = main()
    exit(0 if triggered else 1)
