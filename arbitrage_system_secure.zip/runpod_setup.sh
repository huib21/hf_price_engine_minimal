#!/bin/bash

# RUNPOD GPU SETUP SCRIPT
# Run this once on your RunPod instance to setup the environment

set -e  # Exit on error

echo "========================================"
echo "RUNPOD GPU SETUP FOR ARBITRAGE SYSTEM"
echo "========================================"
echo ""

# 1. Update system
echo "📦 Updating system packages..."
apt-get update -qq
apt-get install -y git python3-pip python3-venv curl -qq

# 2. Create workspace
WORKSPACE="/workspace/arbitrage"
echo "📁 Creating workspace at $WORKSPACE..."
mkdir -p $WORKSPACE
cd $WORKSPACE

# 3. Clone repository
echo "📥 Cloning repository..."
REPO_URL="https://github.com/huib21/hf_price_engine_minimal.git"

if [ -d "hf_price_engine_minimal" ]; then
    echo "   Repository already exists, pulling latest..."
    cd hf_price_engine_minimal
    git pull origin main
else
    git clone $REPO_URL
    cd hf_price_engine_minimal
fi

echo "✓ Repository cloned/updated"

# 4. Create virtual environment
echo "🐍 Setting up Python environment..."
python3 -m venv venv
source venv/bin/activate

# 5. Install dependencies
echo "📦 Installing Python dependencies..."

# Core dependencies
pip install --upgrade pip -q
pip install aiohttp numpy pandas -q

# GPU dependencies - CuPy
echo "🚀 Installing GPU acceleration (CuPy)..."

# Detect CUDA version
if command -v nvidia-smi &> /dev/null; then
    CUDA_VERSION=$(nvidia-smi | grep "CUDA Version" | awk '{print $9}' | cut -d'.' -f1)
    echo "   Detected CUDA version: $CUDA_VERSION"
    
    if [ "$CUDA_VERSION" == "12" ]; then
        pip install cupy-cuda12x -q
    elif [ "$CUDA_VERSION" == "11" ]; then
        pip install cupy-cuda11x -q
    else
        echo "   ⚠️  Unknown CUDA version, installing CUDA 12 CuPy..."
        pip install cupy-cuda12x -q
    fi
    
    echo "✓ CuPy installed for GPU acceleration"
else
    echo "   ⚠️  nvidia-smi not found, skipping GPU libraries"
fi

# 6. Test GPU
echo ""
echo "🧪 Testing GPU availability..."
python3 << 'EOF'
try:
    import cupy as cp
    print("✓ CuPy imported successfully")
    
    # Test GPU
    x = cp.array([1, 2, 3])
    print(f"✓ GPU test passed: {x}")
    
    # Print GPU info
    print(f"✓ GPU Device: {cp.cuda.Device().name}")
    
except ImportError:
    print("⚠️  CuPy not available - will use CPU fallback")
except Exception as e:
    print(f"⚠️  GPU test failed: {e}")
EOF

# 7. Create convenience scripts
echo ""
echo "📝 Creating convenience scripts..."

# Run router script
cat > run_router.sh << 'EORUN'
#!/bin/bash
cd /workspace/arbitrage/hf_price_engine_minimal
source venv/bin/activate
python3 gpu_multihop_router.py
EORUN

chmod +x run_router.sh

echo "✓ Created run_router.sh"

# 8. Setup data directory
echo "📂 Setting up data directories..."
mkdir -p data
mkdir -p logs

# 9. Test pool data availability
echo ""
echo "📊 Checking for pool data..."
if [ -f "pools_for_gpu.json" ]; then
    echo "✓ Pool data found"
else
    echo "⚠️  pools_for_gpu.json not found"
    echo "   Upload it before running the router"
fi

# 10. Summary
echo ""
echo "========================================"
echo "✅ SETUP COMPLETE!"
echo "========================================"
echo ""
echo "📍 Workspace: $WORKSPACE/hf_price_engine_minimal"
echo ""
echo "🚀 To run the GPU router:"
echo "   cd $WORKSPACE/hf_price_engine_minimal"
echo "   source venv/bin/activate"
echo "   python3 gpu_multihop_router.py"
echo ""
echo "Or use the convenience script:"
echo "   ./run_router.sh"
echo ""
echo "⚠️  Make sure pools_for_gpu.json is uploaded first!"
echo "========================================"
