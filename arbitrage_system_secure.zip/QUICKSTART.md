# 🚀 QUICK START GUIDE

## 📥 1. Download & Setup (5 minuten)

```bash
# Clone repository
git clone https://github.com/huib21/hf_price_engine_minimal.git
cd hf_price_engine_minimal

# Install dependencies
pip3 install -r requirements.txt

# Test system
python3 test_system.py
```

## ✅ 2. Verify Everything Works

De test script controleert:
- ✓ Python modules
- ✓ Alle bestanden aanwezig
- ✓ Telegram bot werkt
- ✓ RunPod API werkt
- ✓ Price tracker output

## 🎮 3. Start the System

**Terminal 1: Price Tracker (laat draaien)**
```bash
python3 multi_dex_prices_realistic.py
```
Wacht tot je ziet:
```
✓ Saved to realistic_arbitrage.json
✓ Exported X pools to pools_for_gpu.json for GPU routing
```

**Terminal 2: Orchestrator (laat draaien)**
```bash
python3 orchestrator.py
```
Je ziet nu:
```
🤖 ARBITRAGE ORCHESTRATOR STARTED
Monitoring for opportunities every 10s
```

## 📱 4. Telegram Notifications

Je krijgt berichten als:
- 🚀 Winstkansen gedetecteerd
- ✅ GPU gestart
- 🎯 Route analysis compleet
- ⏸️ GPU gestopt

## 🎯 5. Wat gebeurt er nu?

```
Elke 10 seconden:
  └─> Check voor arbitrage kansen
      
Als winstkans gedetecteerd (€5+ potentie):
  1. 📱 Telegram alert
  2. 🚀 Start RunPod GPU
  3. 🧮 Run multi-hop analysis
  4. 📊 Stuur resultaten
  5. ⏸️ Stop GPU (cost saving)
```

## ⚙️ 6. Configuratie Aanpassen

Edit `orchestrator.py`, rond regel 300:

```python
config = {
    'volatility': {
        'min_opportunities': 2,              # Pas aan: meer/minder strict
        'min_spread_pct': 0.8,              # Minimale spread %
        'min_potential_profit_eur': 5.0,    # Minimale winst in EUR
        'test_capital_eur': 250,            # Je inleg
    },
    'monitoring': {
        'check_interval_seconds': 10,       # Hoe vaak checken
        'max_gpu_runtime_minutes': 10,      # Max GPU tijd per run
    }
}
```

## 💰 7. Kosten Tracking

GPU: RTXA6000 @ ~$0.79/uur
- Gemiddelde run: 3-5 minuten = $0.04-0.07
- Auto-stop na elke analysis
- Orchestrator toont totale kosten

## 🔧 8. Troubleshooting

### Geen Telegram berichten?
```bash
python3 telegram_notifier.py
# Test of bot werkt
```

### GPU start niet?
```bash
python3 runpod_controller.py status
# Check pod status
```

### Geen arbitrage kansen?
```bash
# Pas thresholds aan in orchestrator.py:
'min_potential_profit_eur': 2.0,  # Lager = meer triggers
'min_spread_pct': 0.5,            # Lager = meer kansen
```

### Price tracker errors?
- Check internet verbinding
- SSL errors zijn OK (development mode)
- Wacht 30 seconden voor eerste data

## 📊 9. Logs & Output

Bestanden die worden gemaakt:
- `realistic_arbitrage.json` - Huidige kansen
- `pools_for_gpu.json` - Data voor GPU
- `multihop_routes.json` - GPU resultaten

## 🛑 10. Stoppen

Stop beide terminals met `Ctrl+C`

Het systeem:
- Stopt automatisch de GPU
- Stuurt laatste cost report
- Sluit netjes af

## 💡 11. Pro Tips

**Cost Saving:**
- Set `max_gpu_runtime_minutes` laag (5-10 min)
- Enable `auto_stop_after_analysis: True`
- Monitor daily via Telegram berichten

**Better Opportunities:**
- Run tijdens hoge volatiliteit (Amerikaanse handelsuren)
- Lagere thresholds = meer GPU activatie = hogere kosten
- Start conservatief, pas aan op basis van resultaten

**Testing:**
- Eerste dag: hoge thresholds (€10+ profit)
- Monitor wat je mist/vindt
- Pas geleidelijk aan

## 📈 12. Next Steps

Als system goed draait:
1. ✅ Analyseer gevonden routes handmatig
2. ✅ Test met kleine trades via test wallet
3. ✅ Build transaction executor (volgende fase)
4. ✅ Automatiseer execution (toekomst)

## ⚠️ 13. Belangrijke Reminders

- 💰 Test wallet: Max €250 (zoals geconfigureerd)
- 🔒 API keys zijn in code (OK voor test, niet voor productie)
- 📊 Dit is monitoring/analysis - GEEN auto-trading (nog niet)
- ⏰ Mac moet 24/7 draaien (of gebruik VPS)
- 💸 Monitor RunPod credits dagelijks

## 🆘 14. Help Needed?

1. Run `python3 test_system.py` voor diagnostics
2. Check logs in terminal output
3. Telegram bot stuurt error alerts
4. GitHub issues voor bugs

---

**Ready? Start met stap 1! 🚀**

Veel succes met arbitrage hunting! 💰
