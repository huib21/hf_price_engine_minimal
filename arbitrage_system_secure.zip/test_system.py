#!/usr/bin/env python3
"""
SYSTEM TEST SCRIPT
Tests all components before running the full orchestrator
"""

import sys
import os
from datetime import datetime

def print_header(text):
    print("\n" + "="*80)
    print(f" {text}")
    print("="*80)

def test_imports():
    """Test if all required modules can be imported"""
    print_header("TEST 1: Module Imports")
    
    required_modules = [
        ("aiohttp", "Price tracker"),
        ("numpy", "Data processing"),
        ("requests", "API calls"),
    ]
    
    all_ok = True
    for module, purpose in required_modules:
        try:
            __import__(module)
            print(f"✓ {module:15} - {purpose}")
        except ImportError:
            print(f"❌ {module:15} - {purpose} (MISSING)")
            all_ok = False
    
    # Test GPU (optional)
    try:
        import cupy as cp
        x = cp.array([1, 2, 3])
        print(f"✓ {'cupy':15} - GPU acceleration (AVAILABLE)")
    except:
        print(f"⚠️  {'cupy':15} - GPU acceleration (Not available, will use CPU)")
    
    return all_ok

def test_files():
    """Test if all required files exist"""
    print_header("TEST 2: Required Files")
    
    required_files = [
        "multi_dex_prices_realistic.py",
        "gpu_multihop_router.py",
        "orchestrator.py",
        "volatility_detector.py",
        "runpod_controller.py",
        "telegram_notifier.py",
    ]
    
    all_ok = True
    for filename in required_files:
        if os.path.exists(filename):
            print(f"✓ {filename}")
        else:
            print(f"❌ {filename} (MISSING)")
            all_ok = False
    
    return all_ok

def test_telegram():
    """Test Telegram bot connection"""
    print_header("TEST 3: Telegram Bot")
    
    try:
        from telegram_notifier import TelegramNotifier
        from dotenv import load_dotenv
        
        load_dotenv()
        
        BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
        CHAT_ID = os.getenv('TELEGRAM_CHAT_ID')
        
        if not BOT_TOKEN or not CHAT_ID:
            print("❌ Missing TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID in .env file")
            return False
        
        notifier = TelegramNotifier(BOT_TOKEN, CHAT_ID)
        
        print("Sending test message...")
        success = notifier.send_message(
            "🧪 <b>System Test</b>\n\n"
            f"This is a test message from the arbitrage system.\n"
            f"Time: {datetime.now().strftime('%H:%M:%S')}\n\n"
            "<i>If you receive this, Telegram integration is working!</i>"
        )
        
        if success:
            print("✓ Telegram test message sent successfully")
            print("  Check your Telegram to confirm receipt")
            return True
        else:
            print("❌ Failed to send Telegram message")
            return False
    
    except Exception as e:
        print(f"❌ Telegram test failed: {e}")
        return False

def test_runpod():
    """Test RunPod API connection"""
    print_header("TEST 4: RunPod Connection")
    
    try:
        from runpod_controller import RunPodController
        from dotenv import load_dotenv
        
        load_dotenv()
        
        API_KEY = os.getenv('RUNPOD_API_KEY')
        POD_ID = os.getenv('RUNPOD_POD_ID')
        
        if not API_KEY or not POD_ID:
            print("❌ Missing RUNPOD_API_KEY or RUNPOD_POD_ID in .env file")
            return False
        
        controller = RunPodController(API_KEY, POD_ID)
        
        print("Checking pod status...")
        status, details = controller.get_pod_status()
        
        if status == "ERROR":
            print(f"❌ RunPod API error: {details.get('error', 'Unknown')}")
            return False
        
        print(f"✓ RunPod API connection successful")
        print(f"  Pod Status: {status}")
        
        if status == "RUNNING":
            info = controller.get_pod_info()
            print(f"  GPU: {info.get('gpu', 'Unknown')}")
            print(f"  Uptime: {info.get('uptime_hours', 0):.1f}h")
            print(f"  Cost so far: ${info.get('estimated_cost_usd', 0):.2f}")
        
        return True
    
    except Exception as e:
        print(f"❌ RunPod test failed: {e}")
        return False

def test_price_tracker_output():
    """Check if price tracker has created output files"""
    print_header("TEST 5: Price Tracker Output")
    
    files_to_check = [
        ("realistic_arbitrage.json", "Arbitrage opportunities"),
        ("pools_for_gpu.json", "GPU pool data"),
    ]
    
    all_ok = True
    for filename, description in files_to_check:
        if os.path.exists(filename):
            # Check file age
            import time
            age_seconds = time.time() - os.path.getmtime(filename)
            age_minutes = age_seconds / 60
            
            print(f"✓ {filename:30} ({description})")
            print(f"  Last updated: {age_minutes:.1f} minutes ago")
            
            if age_minutes > 5:
                print(f"  ⚠️  File is older than 5 minutes - is price tracker running?")
        else:
            print(f"⚠️  {filename:30} (Not found - run price tracker first)")
            all_ok = False
    
    if not all_ok:
        print("\n💡 To create these files, run:")
        print("   python3 multi_dex_prices_realistic.py")
        print("   (Let it run for at least 1 iteration)")
    
    return all_ok

def test_volatility_detector():
    """Test volatility detection"""
    print_header("TEST 6: Volatility Detector")
    
    try:
        from volatility_detector import VolatilityDetector
        
        detector = VolatilityDetector()
        
        print("Analyzing current market conditions...")
        signal = detector.load_from_file("realistic_arbitrage.json")
        
        print(f"\n{signal.reason}")
        print(f"Opportunities: {signal.opportunity_count}")
        print(f"Best spread: {signal.best_spread_pct:.2f}%")
        print(f"Potential profit: €{signal.total_potential_profit_eur:.2f}")
        print(f"GPU Trigger: {'YES ✅' if signal.triggered else 'NO ⏸️'}")
        
        return True
    
    except FileNotFoundError:
        print("⚠️  realistic_arbitrage.json not found")
        print("   Run price tracker first")
        return False
    except Exception as e:
        print(f"❌ Volatility detector test failed: {e}")
        return False

def main():
    """Run all tests"""
    
    print("\n")
    print("╔" + "="*78 + "╗")
    print("║" + " "*20 + "ARBITRAGE SYSTEM TEST SUITE" + " "*31 + "║")
    print("╚" + "="*78 + "╝")
    
    results = {}
    
    # Run tests
    results['imports'] = test_imports()
    results['files'] = test_files()
    results['telegram'] = test_telegram()
    results['runpod'] = test_runpod()
    results['price_data'] = test_price_tracker_output()
    results['volatility'] = test_volatility_detector()
    
    # Summary
    print_header("TEST SUMMARY")
    
    total = len(results)
    passed = sum(1 for v in results.values() if v)
    
    for test_name, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{test_name.upper():20} {status}")
    
    print("\n" + "="*80)
    print(f"TOTAL: {passed}/{total} tests passed")
    print("="*80)
    
    if passed == total:
        print("\n🎉 All tests passed! System is ready to run.")
        print("\n📝 Next steps:")
        print("   1. Terminal 1: python3 multi_dex_prices_realistic.py")
        print("   2. Terminal 2: python3 orchestrator.py")
        return 0
    else:
        print("\n⚠️  Some tests failed. Please fix issues before running.")
        print("\n💡 Common fixes:")
        print("   • Missing modules: pip3 install -r requirements.txt")
        print("   • Missing files: Make sure all .py files are present")
        print("   • Price data: Run multi_dex_prices_realistic.py first")
        return 1

if __name__ == "__main__":
    sys.exit(main())
