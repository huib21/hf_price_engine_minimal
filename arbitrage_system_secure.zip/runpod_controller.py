"""
RUNPOD CONTROLLER
Manages RunPod GPU pod lifecycle via API
"""

import requests
import time
import json
import os
from typing import Optional, Dict, Tuple
from datetime import datetime


class RunPodController:
    """Control RunPod GPU instances via API"""
    
    def __init__(self, api_key: str, pod_id: str):
        self.api_key = api_key
        self.pod_id = pod_id
        self.base_url = "https://api.runpod.io/graphql"
        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        }
        
    def _graphql_query(self, query: str, variables: Dict = None) -> Dict:
        """Execute GraphQL query against RunPod API"""
        payload = {
            "query": query,
            "variables": variables or {}
        }
        
        try:
            response = requests.post(
                self.base_url,
                json=payload,
                headers=self.headers,
                timeout=30
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"❌ RunPod API Error: {e}")
            return {"errors": [{"message": str(e)}]}
    
    def get_pod_status(self) -> Tuple[str, Dict]:
        """
        Get current pod status
        
        Returns:
            (status, details) where status is 'RUNNING', 'STOPPED', etc.
        """
        query = """
        query Pod($podId: String!) {
            pod(input: {podId: $podId}) {
                id
                name
                runtime {
                    uptimeInSeconds
                    ports {
                        ip
                        isIpPublic
                        privatePort
                        publicPort
                        type
                    }
                    gpus {
                        id
                        gpuUtilPercent
                        memoryUtilPercent
                    }
                    container {
                        cpuPercent
                        memoryPercent
                    }
                }
                machine {
                    podHostId
                }
                desiredStatus
                imageName
                env
                machineId
                machine {
                    gpuDisplayName
                }
            }
        }
        """
        
        result = self._graphql_query(query, {"podId": self.pod_id})
        
        if "errors" in result:
            return "ERROR", {"error": result["errors"][0]["message"]}
        
        pod_data = result.get("data", {}).get("pod", {})
        
        if not pod_data:
            return "NOT_FOUND", {}
        
        # Determine status
        desired_status = pod_data.get("desiredStatus", "UNKNOWN")
        runtime = pod_data.get("runtime")
        
        if runtime:
            status = "RUNNING"
        elif desired_status == "RUNNING":
            status = "STARTING"
        else:
            status = "STOPPED"
        
        return status, pod_data
    
    def start_pod(self, timeout_seconds: int = 300) -> bool:
        """
        Start the pod and wait for it to be ready
        
        Args:
            timeout_seconds: Maximum time to wait for pod to start
            
        Returns:
            True if started successfully, False otherwise
        """
        print(f"🚀 Starting RunPod GPU ({self.pod_id})...")
        
        # Check current status first
        status, details = self.get_pod_status()
        
        if status == "RUNNING":
            print("✓ Pod already running")
            return True
        
        if status == "ERROR" or status == "NOT_FOUND":
            print(f"❌ Cannot start pod: {status}")
            if details.get('error'):
                print(f"   Error: {details['error']}")
            return False
        
        # Start pod
        mutation = """
        mutation StartPod($podId: String!) {
            podResume(input: {podId: $podId}) {
                id
                desiredStatus
            }
        }
        """
        
        result = self._graphql_query(mutation, {"podId": self.pod_id})
        
        if "errors" in result:
            print(f"❌ Failed to start pod: {result['errors'][0]['message']}")
            return False
        
        print("⏳ Waiting for pod to start...")
        
        # Poll until running or timeout
        start_time = time.time()
        while time.time() - start_time < timeout_seconds:
            status, details = self.get_pod_status()
            
            if status == "RUNNING":
                uptime = details.get("runtime", {}).get("uptimeInSeconds", 0)
                gpu_name = details.get("machine", {}).get("gpuDisplayName", "Unknown")
                print(f"✓ Pod started successfully!")
                print(f"  GPU: {gpu_name}")
                print(f"  Uptime: {uptime}s")
                return True
            
            elif status == "ERROR":
                print(f"❌ Pod failed to start: {details}")
                return False
            
            time.sleep(5)
        
        print(f"❌ Timeout waiting for pod to start ({timeout_seconds}s)")
        return False
    
    def stop_pod(self) -> bool:
        """
        Stop the pod
        
        Returns:
            True if stopped successfully, False otherwise
        """
        print(f"⏸️  Stopping RunPod GPU ({self.pod_id})...")
        
        # Check current status
        status, details = self.get_pod_status()
        
        if status == "STOPPED":
            print("✓ Pod already stopped")
            return True
        
        if status == "ERROR" or status == "NOT_FOUND":
            print(f"❌ Cannot stop pod: {status}")
            return False
        
        # Stop pod
        mutation = """
        mutation StopPod($podId: String!) {
            podStop(input: {podId: $podId}) {
                id
                desiredStatus
            }
        }
        """
        
        result = self._graphql_query(mutation, {"podId": self.pod_id})
        
        if "errors" in result:
            print(f"❌ Failed to stop pod: {result['errors'][0]['message']}")
            return False
        
        print("✓ Pod stop command sent successfully")
        
        # Wait a bit to confirm
        time.sleep(3)
        status, _ = self.get_pod_status()
        
        if status in ["STOPPED", "STOPPING"]:
            print("✓ Pod stopped")
            return True
        else:
            print(f"⚠️  Pod status: {status} (may still be stopping)")
            return True  # Command was successful even if not fully stopped yet
    
    def execute_remote_command(self, command: str, ssh_port: int = 22) -> bool:
        """
        Execute command on running pod via SSH (requires SSH setup)
        
        Note: This is a placeholder - actual SSH execution requires paramiko
        """
        print(f"📡 Would execute on pod: {command}")
        print("   (SSH execution not implemented - use RunPod web terminal or setup paramiko)")
        return False
    
    def get_estimated_cost(self, runtime_hours: float) -> float:
        """
        Estimate cost for runtime
        
        RTXA6000 typical pricing: ~$0.79/hr on-demand
        """
        hourly_rate = 0.79  # USD per hour for RTXA6000 (approximate)
        return runtime_hours * hourly_rate
    
    def get_pod_info(self) -> Dict:
        """Get detailed pod information"""
        status, details = self.get_pod_status()
        
        info = {
            "pod_id": self.pod_id,
            "status": status,
            "timestamp": datetime.now().isoformat()
        }
        
        if status == "RUNNING":
            runtime = details.get("runtime", {})
            uptime_seconds = runtime.get("uptimeInSeconds", 0)
            uptime_hours = uptime_seconds / 3600
            
            info.update({
                "uptime_seconds": uptime_seconds,
                "uptime_hours": round(uptime_hours, 2),
                "estimated_cost_usd": round(self.get_estimated_cost(uptime_hours), 2),
                "gpu": details.get("machine", {}).get("gpuDisplayName", "Unknown"),
                "gpu_util": runtime.get("gpus", [{}])[0].get("gpuUtilPercent", 0) if runtime.get("gpus") else 0,
            })
        
        return info


def main():
    """Test RunPod controller"""
    import sys
    from dotenv import load_dotenv
    
    load_dotenv()
    
    # Configuration from environment variables
    API_KEY = os.getenv('RUNPOD_API_KEY')
    POD_ID = os.getenv('RUNPOD_POD_ID')
    
    if not API_KEY or not POD_ID:
        print("❌ ERROR: Missing environment variables!")
        print("Set RUNPOD_API_KEY and RUNPOD_POD_ID in .env file")
        sys.exit(1)
    
    controller = RunPodController(API_KEY, POD_ID)
    
    print("RUNPOD CONTROLLER TEST")
    print("="*80)
    
    # Get current status
    print("\n1. Checking pod status...")
    status, details = controller.get_pod_status()
    print(f"   Status: {status}")
    
    if status == "RUNNING":
        info = controller.get_pod_info()
        print(f"   GPU: {info.get('gpu')}")
        print(f"   Uptime: {info.get('uptime_hours')}h")
        print(f"   Estimated cost: ${info.get('estimated_cost_usd')}")
    
    # Command line interface
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        
        if command == "start":
            success = controller.start_pod()
            sys.exit(0 if success else 1)
        
        elif command == "stop":
            success = controller.stop_pod()
            sys.exit(0 if success else 1)
        
        elif command == "status":
            info = controller.get_pod_info()
            print(json.dumps(info, indent=2))
            sys.exit(0)
        
        else:
            print(f"\nUnknown command: {command}")
            print("Usage: python runpod_controller.py [start|stop|status]")
            sys.exit(1)
    else:
        print("\nUsage: python runpod_controller.py [start|stop|status]")
        print("Or import and use RunPodController class")
    
    print("="*80)


if __name__ == "__main__":
    main()
