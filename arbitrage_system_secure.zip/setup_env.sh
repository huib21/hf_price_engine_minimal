#!/bin/bash

# SETUP SCRIPT FOR ENVIRONMENT VARIABLES
# This script helps you setup your .env file safely

echo "=========================================="
echo "ARBITRAGE SYSTEM - ENVIRONMENT SETUP"
echo "=========================================="
echo ""

# Check if .env already exists
if [ -f .env ]; then
    echo "⚠️  .env file already exists!"
    read -p "Do you want to overwrite it? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Cancelled. Existing .env file preserved."
        exit 0
    fi
fi

# Create .env file
echo "Creating .env file..."
echo ""

# Prompt for RunPod credentials
echo "📦 RunPod Configuration"
echo "-----------------------"
read -p "RunPod API Key: " RUNPOD_API_KEY
read -p "RunPod Pod ID: " RUNPOD_POD_ID
echo ""

# Prompt for Telegram credentials
echo "📱 Telegram Configuration"
echo "-------------------------"
read -p "Telegram Bot Token: " TELEGRAM_BOT_TOKEN
read -p "Telegram Chat ID: " TELEGRAM_CHAT_ID
echo ""

# Write to .env file
cat > .env << EOF
# Environment Variables for Arbitrage System
# Generated on $(date)

# RunPod Configuration
RUNPOD_API_KEY=$RUNPOD_API_KEY
RUNPOD_POD_ID=$RUNPOD_POD_ID

# Telegram Configuration
TELEGRAM_BOT_TOKEN=$TELEGRAM_BOT_TOKEN
TELEGRAM_CHAT_ID=$TELEGRAM_CHAT_ID
EOF

echo "✅ .env file created successfully!"
echo ""
echo "Your credentials are stored in .env (not tracked by git)"
echo ""
echo "Next steps:"
echo "  1. Install dependencies: pip3 install -r requirements.txt"
echo "  2. Test system: python3 test_system.py"
echo "  3. Start trading: python3 orchestrator.py"
echo ""
