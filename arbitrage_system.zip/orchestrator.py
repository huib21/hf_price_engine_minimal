"""
ARBITRAGE ORCHESTRATOR
Coordinates price tracking, volatility detection, GPU activation, and notifications

Workflow:
1. Monitor price tracker output
2. Detect volatility/opportunities
3. Trigger GPU on RunPod when needed
4. Send Telegram alerts
5. Cleanup and cost tracking
"""

import asyncio
import json
import time
import subprocess
import os
from datetime import datetime, timedelta
from typing import Optional, Dict
import signal
import sys

from volatility_detector import VolatilityDetector, VolatilitySignal
from runpod_controller import RunPodController
from telegram_notifier import TelegramNotifier


class ArbitrageOrchestrator:
    """Main orchestration system"""
    
    def __init__(self, config: Dict):
        self.config = config
        
        # Initialize components
        self.detector = VolatilityDetector(config['volatility'])
        self.runpod = RunPodController(
            config['runpod']['api_key'],
            config['runpod']['pod_id']
        )
        self.telegram = TelegramNotifier(
            config['telegram']['bot_token'],
            config['telegram']['chat_id']
        )
        
        # State tracking
        self.gpu_active = False
        self.gpu_start_time: Optional[datetime] = None
        self.last_alert_time: Optional[datetime] = None
        self.total_gpu_runtime_hours = 0.0
        self.iteration_count = 0
        
        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
        self.running = True
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals gracefully"""
        print("\n\n⚠️  Shutdown signal received...")
        self.running = False
        
        if self.gpu_active:
            print("🛑 Stopping GPU before exit...")
            self.runpod.stop_pod()
            self.telegram.send_gpu_status("STOPPED", {"reason": "Manual shutdown"})
    
    async def monitor_and_trigger(self):
        """Main monitoring loop"""
        
        print("="*80)
        print("🤖 ARBITRAGE ORCHESTRATOR STARTED")
        print("="*80)
        print(f"• Monitoring interval: {self.config['monitoring']['check_interval_seconds']}s")
        print(f"• Alert cooldown: {self.config['monitoring']['alert_cooldown_minutes']}m")
        print(f"• Max GPU runtime: {self.config['monitoring']['max_gpu_runtime_minutes']}m")
        print("="*80)
        
        # Send startup notification
        self.telegram.send_message(
            "🤖 <b>Arbitrage Orchestrator Started</b>\n\n"
            f"Monitoring for opportunities every {self.config['monitoring']['check_interval_seconds']}s\n"
            f"GPU will activate on profitable opportunities"
        )
        
        try:
            while self.running:
                self.iteration_count += 1
                print(f"\n[{datetime.now().strftime('%H:%M:%S')}] Iteration {self.iteration_count}")
                
                # Check for opportunities
                signal = self.detector.load_from_file("realistic_arbitrage.json")
                
                print(f"  {signal.reason}")
                
                # Decide if we should trigger GPU
                should_activate_gpu = (
                    signal.triggered and
                    not self.gpu_active and
                    self._should_send_alert()
                )
                
                if should_activate_gpu:
                    await self._handle_gpu_activation(signal)
                
                elif signal.triggered and self.gpu_active:
                    print("  ℹ️  GPU already running, monitoring continues...")
                
                # Check if GPU should be stopped
                if self.gpu_active:
                    await self._check_gpu_runtime()
                
                # Periodic status update (every 10 iterations)
                if self.iteration_count % 10 == 0:
                    self._print_status()
                
                # Wait before next check
                await asyncio.sleep(self.config['monitoring']['check_interval_seconds'])
        
        except Exception as e:
            error_msg = f"Orchestrator error: {str(e)}"
            print(f"\n❌ {error_msg}")
            self.telegram.send_error(error_msg, "Main monitoring loop")
        
        finally:
            await self._cleanup()
    
    async def _handle_gpu_activation(self, signal: VolatilitySignal):
        """Handle GPU activation workflow"""
        
        print("\n🚀 TRIGGERING GPU WORKFLOW")
        print("="*80)
        
        # 1. Send Telegram alert
        print("1. Sending Telegram alert...")
        alert_sent = self.telegram.send_volatility_alert(signal.__dict__)
        
        if alert_sent:
            print("   ✓ Alert sent")
            self.last_alert_time = datetime.now()
        else:
            print("   ⚠️  Alert failed, continuing anyway")
        
        # 2. Start RunPod GPU
        print("\n2. Starting RunPod GPU...")
        gpu_started = self.runpod.start_pod(timeout_seconds=300)
        
        if not gpu_started:
            error_msg = "Failed to start GPU pod"
            print(f"   ❌ {error_msg}")
            self.telegram.send_error(error_msg, "GPU activation")
            return
        
        print("   ✓ GPU started")
        self.gpu_active = True
        self.gpu_start_time = datetime.now()
        
        # Send GPU status
        pod_info = self.runpod.get_pod_info()
        self.telegram.send_gpu_status("RUNNING", pod_info)
        
        # 3. Wait a moment for GPU to be ready
        print("\n3. Waiting for GPU to initialize...")
        await asyncio.sleep(10)
        
        # 4. Trigger GPU multi-hop router
        print("\n4. Running GPU multi-hop router...")
        await self._run_gpu_router()
        
        # 5. Send results
        print("\n5. Sending results...")
        await self._send_results()
        
        # 6. Stop GPU (cost saving)
        if self.config['runpod']['auto_stop_after_analysis']:
            print("\n6. Stopping GPU (cost saving)...")
            await self._stop_gpu()
        else:
            print("\n6. GPU kept running (auto_stop disabled)")
        
        print("\n" + "="*80)
    
    async def _run_gpu_router(self):
        """Execute GPU multi-hop router on RunPod"""
        
        # For now, we'll run it locally since SSH execution is complex
        # In production, you'd SSH into RunPod and run there
        
        print("   ℹ️  Running GPU router locally (SSH execution not implemented)")
        print("   ℹ️  In production: SSH to RunPod and execute there")
        
        try:
            # Check if pools_for_gpu.json exists
            if not os.path.exists("pools_for_gpu.json"):
                print("   ⚠️  pools_for_gpu.json not found, skipping router")
                return
            
            # Run the GPU router
            result = subprocess.run(
                ["python3", "gpu_multihop_router.py"],
                capture_output=True,
                text=True,
                timeout=120
            )
            
            if result.returncode == 0:
                print("   ✓ GPU router completed successfully")
            else:
                print(f"   ⚠️  GPU router exited with code {result.returncode}")
                if result.stderr:
                    print(f"   Error: {result.stderr[:200]}")
        
        except subprocess.TimeoutExpired:
            print("   ⚠️  GPU router timeout (120s)")
        except FileNotFoundError:
            print("   ⚠️  gpu_multihop_router.py not found in current directory")
        except Exception as e:
            print(f"   ⚠️  Error running GPU router: {e}")
    
    async def _send_results(self):
        """Send route analysis results via Telegram"""
        
        try:
            if os.path.exists("multihop_routes.json"):
                with open("multihop_routes.json", 'r') as f:
                    results = json.load(f)
                
                self.telegram.send_route_results(results)
                print("   ✓ Results sent via Telegram")
            else:
                print("   ⚠️  No results file found")
        
        except Exception as e:
            print(f"   ⚠️  Error sending results: {e}")
    
    async def _stop_gpu(self):
        """Stop GPU and update tracking"""
        
        if not self.gpu_active:
            return
        
        # Calculate runtime
        if self.gpu_start_time:
            runtime = datetime.now() - self.gpu_start_time
            runtime_hours = runtime.total_seconds() / 3600
            self.total_gpu_runtime_hours += runtime_hours
            
            cost = self.runpod.get_estimated_cost(runtime_hours)
            
            print(f"   Runtime: {runtime_hours:.2f}h | Cost: ${cost:.2f}")
        
        # Stop pod
        stopped = self.runpod.stop_pod()
        
        if stopped:
            self.gpu_active = False
            self.gpu_start_time = None
            print("   ✓ GPU stopped")
            
            # Send stop notification
            self.telegram.send_gpu_status("STOPPED", {
                "runtime_hours": runtime_hours if self.gpu_start_time else 0,
                "estimated_cost_usd": cost if self.gpu_start_time else 0
            })
        else:
            print("   ⚠️  Failed to stop GPU")
    
    async def _check_gpu_runtime(self):
        """Check if GPU should be stopped due to max runtime"""
        
        if not self.gpu_active or not self.gpu_start_time:
            return
        
        runtime = datetime.now() - self.gpu_start_time
        runtime_minutes = runtime.total_seconds() / 60
        max_runtime = self.config['monitoring']['max_gpu_runtime_minutes']
        
        if runtime_minutes >= max_runtime:
            print(f"\n⏰ Max GPU runtime reached ({max_runtime}m), stopping...")
            await self._stop_gpu()
    
    def _should_send_alert(self) -> bool:
        """Check if enough time has passed since last alert"""
        
        if not self.last_alert_time:
            return True
        
        cooldown = timedelta(minutes=self.config['monitoring']['alert_cooldown_minutes'])
        time_since_last = datetime.now() - self.last_alert_time
        
        return time_since_last >= cooldown
    
    def _print_status(self):
        """Print periodic status update"""
        
        print("\n" + "="*80)
        print("📊 STATUS UPDATE")
        print("="*80)
        print(f"• Iterations: {self.iteration_count}")
        print(f"• GPU Active: {'Yes ✅' if self.gpu_active else 'No ⏸️'}")
        
        if self.gpu_active and self.gpu_start_time:
            runtime = datetime.now() - self.gpu_start_time
            print(f"• Current Runtime: {runtime.total_seconds()/60:.1f}m")
        
        print(f"• Total GPU Runtime: {self.total_gpu_runtime_hours:.2f}h")
        print(f"• Estimated Total Cost: ${self.runpod.get_estimated_cost(self.total_gpu_runtime_hours):.2f}")
        
        if self.last_alert_time:
            time_since = datetime.now() - self.last_alert_time
            print(f"• Last Alert: {time_since.total_seconds()/60:.0f}m ago")
        
        print("="*80)
    
    async def _cleanup(self):
        """Cleanup on shutdown"""
        
        print("\n🧹 Cleaning up...")
        
        if self.gpu_active:
            print("• Stopping GPU...")
            await self._stop_gpu()
        
        # Send shutdown notification
        self.telegram.send_message(
            "⏹️ <b>Arbitrage Orchestrator Stopped</b>\n\n"
            f"Total iterations: {self.iteration_count}\n"
            f"Total GPU runtime: {self.total_gpu_runtime_hours:.2f}h\n"
            f"Estimated total cost: ${self.runpod.get_estimated_cost(self.total_gpu_runtime_hours):.2f}"
        )
        
        print("✓ Cleanup complete")


async def main():
    """Main entry point"""
    
    # Configuration
    config = {
        'volatility': {
            'min_opportunities': 2,
            'min_spread_pct': 0.8,
            'min_confidence': 0.70,
            'min_liquidity': 50000,
            'min_potential_profit_eur': 5.0,
            'test_capital_eur': 250,
            'safety_margin': 0.3
        },
        'runpod': {
            'api_key': "rpa_I7JSKBIW5RXTH2XYYVWAQV3EWXHSDF8CZG3ZSGRHz9fmqt",
            'pod_id': "wm5rlslky5pmw3",
            'auto_stop_after_analysis': True  # Stop GPU after each analysis to save cost
        },
        'telegram': {
            'bot_token': "8469215299:AAG13gJXvEQk4CiFAE7v6wOZ3pOKHY-f-sk",
            'chat_id': "6314780875"
        },
        'monitoring': {
            'check_interval_seconds': 10,      # Check every 10 seconds
            'alert_cooldown_minutes': 5,       # Min 5 minutes between alerts
            'max_gpu_runtime_minutes': 10      # Max 10 minutes GPU runtime per activation
        }
    }
    
    orchestrator = ArbitrageOrchestrator(config)
    await orchestrator.monitor_and_trigger()


if __name__ == "__main__":
    asyncio.run(main())
