# Automated Solana Arbitrage System with GPU On-Demand

Complete HF arbitrage tracker met intelligente GPU activering via RunPod en Telegram alerts.

## 🏗️ Architectuur

```
┌─────────────────────────────────────────────────────────────┐
│                     LOCAL MAC (24/7)                         │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  1. multi_dex_prices_realistic.py (continuous)              │
│     └─> Tracks 5 DEXes, filters realistic opportunities     │
│     └─> Exports: realistic_arbitrage.json, pools_for_gpu.json│
│                                                              │
│  2. orchestrator.py (continuous)                            │
│     ├─> Monitors arbitrage opportunities                    │
│     ├─> Triggers GPU when profitable                        │
│     ├─> Sends Telegram alerts                               │
│     └─> Manages cost/runtime                                │
│                                                              │
└─────────────────────────────────────────────────────────────┘
                            │
                            │ API Calls
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    RUNPOD GPU (On-Demand)                    │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  • RTXA6000 GPU (wm5rlslky5pmw3)                            │
│  • Starts automatically when opportunities detected         │
│  • Runs: gpu_multihop_router.py                             │
│  • Finds 2-4 hop arbitrage routes                           │
│  • Auto-stops to save costs (~$0.79/hr)                     │
│                                                              │
└─────────────────────────────────────────────────────────────┘
                            │
                            │ Results
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                      TELEGRAM BOT                            │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  • Opportunity alerts                                        │
│  • GPU status updates                                        │
│  • Route analysis results                                    │
│  • Error notifications                                       │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

## 📦 Bestanden Overzicht

### Core System
- **`multi_dex_prices_realistic.py`** - Price tracker met realistische filtering
- **`orchestrator.py`** - Main coordinator (runs on Mac 24/7)
- **`volatility_detector.py`** - Determines when GPU is needed
- **`runpod_controller.py`** - Controls RunPod GPU via API
- **`telegram_notifier.py`** - Sends Telegram alerts
- **`gpu_multihop_router.py`** - GPU-accelerated multi-hop pathfinding

### Setup & Config
- **`runpod_setup.sh`** - Setup script for RunPod (run once)
- **`requirements.txt`** - Python dependencies
- **`README.md`** - This file

## 🚀 Quick Start

### 1. Local Setup (Mac)

```bash
# Clone repository
git clone https://github.com/huib21/hf_price_engine_minimal.git
cd hf_price_engine_minimal

# Install dependencies
pip3 install -r requirements.txt

# Test Telegram bot
python3 telegram_notifier.py
# Should send test message to your Telegram

# Test RunPod connection
python3 runpod_controller.py status
# Should show pod status
```

### 2. RunPod Setup (One-time)

**Option A: Via RunPod Web Terminal**
```bash
# SSH into your RunPod instance
# Then run:
curl -O https://raw.githubusercontent.com/huib21/hf_price_engine_minimal/main/runpod_setup.sh
chmod +x runpod_setup.sh
./runpod_setup.sh
```

**Option B: Manual Setup**
```bash
cd /workspace
git clone https://github.com/huib21/hf_price_engine_minimal.git
cd hf_price_engine_minimal
pip install cupy-cuda12x numpy aiohttp
```

### 3. Start the System

**Terminal 1: Price Tracker**
```bash
python3 multi_dex_prices_realistic.py
```

**Terminal 2: Orchestrator**
```bash
python3 orchestrator.py
```

That's it! The system is now running.

## ⚙️ Configuration

### Volatility Triggers (in `orchestrator.py`)

```python
'volatility': {
    'min_opportunities': 2,          # Min aantal kansen
    'min_spread_pct': 0.8,          # Min 0.8% spread
    'min_confidence': 0.70,         # Min 70% confidence
    'min_liquidity': 50000,         # Min $50k liquidity
    'min_potential_profit_eur': 5.0, # Min €5 profit potential
    'test_capital_eur': 250,        # Your test capital
    'safety_margin': 0.3            # 30% margin voor fees/slippage
}
```

### Monitoring Settings

```python
'monitoring': {
    'check_interval_seconds': 10,    # Check elke 10s
    'alert_cooldown_minutes': 5,     # Min 5m tussen alerts
    'max_gpu_runtime_minutes': 10    # Max 10m GPU runtime per run
}
```

### RunPod Settings

```python
'runpod': {
    'auto_stop_after_analysis': True  # Auto-stop GPU na analysis (cost saving)
}
```

## 📊 Workflow Example

```
[10:00:00] Iteration 1
  ⏸️  GPU NOT TRIGGERED: Only 1 opportunities (need 2)

[10:00:10] Iteration 2
  ⏸️  GPU NOT TRIGGERED: Best spread 0.6% < 0.8%

[10:00:20] Iteration 3
  🚀 GPU TRIGGERED: 3 opportunities | Best spread: 1.2% | Potential: €8.50

🚀 TRIGGERING GPU WORKFLOW
================================================================================
1. Sending Telegram alert...
   ✓ Alert sent

2. Starting RunPod GPU...
   ✓ Pod started successfully!
     GPU: NVIDIA RTX A6000
     Uptime: 5s

3. Waiting for GPU to initialize...

4. Running GPU multi-hop router...
   ✓ GPU router completed successfully

5. Sending results...
   ✓ Results sent via Telegram

6. Stopping GPU (cost saving)...
   Runtime: 0.08h | Cost: $0.06
   ✓ GPU stopped

================================================================================
```

## 📱 Telegram Notifications

You'll receive:

### Opportunity Alerts
```
🚀 ARBITRAGE ALERT

Status: GPU TRIGGERED ✅
Time: 10:00:20

📊 Market Snapshot:
• Opportunities: 3
• Best Spread: 1.25%
• Potential Profit: €8.50
• High Confidence: 2

🎯 Top Opportunities:
1. SOL
   • Spread: 1.25%
   • Confidence: 85%
   • Route: Raydium → Orca
```

### GPU Status Updates
```
✅ GPU STATUS UPDATE

Status: RUNNING
Time: 10:00:25

Runtime Details:
• GPU: NVIDIA RTX A6000
• Uptime: 0.1h
• Cost: $0.08
```

### Route Results
```
🎯 MULTI-HOP ROUTE ANALYSIS COMPLETE

Total Routes Found: 47

2-HOP: 12 routes
  1. 1.45% profit | 90% conf
     SOL → USDC → SOL
  2. 1.12% profit | 85% conf
     SOL → JUP → SOL

3-HOP: 28 routes
  1. 2.34% profit | 80% conf
     SOL → USDC → RAY → SOL
```

## 💰 Cost Management

### GPU Pricing
- **RTXA6000**: ~$0.79/hour
- **Average run**: 3-5 minutes = ~$0.04-0.07
- **Auto-stop**: Saves costs by stopping GPU after analysis

### Cost Tracking
The orchestrator tracks:
- Per-run GPU time and cost
- Total daily GPU usage
- Reports via Telegram

### Example Daily Usage
```
10 opportunities detected today
Average GPU time per run: 4 minutes
Total GPU time: 40 minutes
Total cost: ~$0.53

Compared to 24/7 GPU: $18.96/day
Savings: $18.43/day (97% reduction!)
```

## 🔧 Troubleshooting

### "pools_for_gpu.json not found"
**Problem**: Orchestrator can't find pool data
**Solution**: Make sure `multi_dex_prices_realistic.py` is running first

### "Failed to start GPU pod"
**Problem**: RunPod API error
**Solutions**:
1. Check API key is correct
2. Check pod ID is correct
3. Check pod isn't already running: `python3 runpod_controller.py status`
4. Check RunPod account has credits

### "GPU router timeout"
**Problem**: GPU router takes too long
**Solutions**:
1. Reduce `max_hops` in GPU router (4 → 3)
2. Increase timeout in orchestrator
3. Check GPU is actually running on RunPod

### No Telegram messages
**Problem**: Bot not sending notifications
**Solutions**:
1. Test bot: `python3 telegram_notifier.py`
2. Check bot token and chat ID
3. Make sure bot is started in Telegram (send /start)

### SSL Errors
**Problem**: Price tracker SSL errors
**Solution**: SSL verification is disabled in development mode (lines 11-14)

## 🎯 Testing the System

### Test 1: Telegram Bot
```bash
python3 telegram_notifier.py
# Should receive test message
```

### Test 2: RunPod Connection
```bash
python3 runpod_controller.py status
# Should show pod details
```

### Test 3: Volatility Detection
```bash
# Run price tracker first
python3 multi_dex_prices_realistic.py
# Wait for 1 iteration, then:
python3 volatility_detector.py
# Shows if GPU would be triggered
```

### Test 4: Full System (Safe)
Set conservative thresholds to prevent accidental GPU starts:
```python
'min_potential_profit_eur': 100.0  # Very high threshold
```
Then run orchestrator and watch for alerts.

## 📈 Next Steps & Enhancements

### Phase 1: Monitoring (Current)
- ✅ Real-time price tracking
- ✅ Volatility detection
- ✅ GPU on-demand activation
- ✅ Telegram alerts

### Phase 2: Analysis (Current)
- ✅ Multi-hop route finding
- ✅ Profit calculation
- ✅ Liquidity filtering

### Phase 3: Execution (Future)
- ⏳ Transaction builder
- ⏳ Slippage calculation
- ⏳ MEV protection
- ⏳ Auto-execution with test wallet

### Phase 4: Optimization (Future)
- ⏳ Position sizing
- ⏳ Risk management
- ⏳ Performance analytics
- ⏳ Backtesting

## ⚠️ Important Notes

### Security
- **API Keys**: Embedded in code for convenience, use env vars in production
- **Test Wallet**: Use dedicated test wallet with limited funds (€250)
- **Never** share API keys publicly

### Costs
- Monitor RunPod usage daily
- Set up billing alerts in RunPod
- GPU auto-stops but always verify

### Trading
- This is **monitoring and analysis only**
- No automatic trading yet
- Always verify opportunities manually before trading

### Legal
- Use at your own risk
- Arbitrage is legal but check local regulations
- Not financial advice

## 📞 Support & Issues

GitHub: https://github.com/huib21/hf_price_engine_minimal
Issues: Create issue on GitHub repo

## 📄 License

MIT License - See LICENSE file

---

**Happy Arbitraging! 🚀💰**
