"""
TELEGRAM NOTIFIER
Sends alerts about arbitrage opportunities
"""

import requests
from typing import List, Dict, Optional
from datetime import datetime


class TelegramNotifier:
    """Send notifications via Telegram bot"""
    
    def __init__(self, bot_token: str, chat_id: str):
        self.bot_token = bot_token
        self.chat_id = chat_id
        self.base_url = f"https://api.telegram.org/bot{bot_token}"
        
    def send_message(self, text: str, parse_mode: str = "HTML") -> bool:
        """
        Send a text message
        
        Args:
            text: Message text (supports HTML formatting)
            parse_mode: 'HTML' or 'Markdown'
            
        Returns:
            True if sent successfully
        """
        url = f"{self.base_url}/sendMessage"
        
        payload = {
            "chat_id": self.chat_id,
            "text": text,
            "parse_mode": parse_mode,
            "disable_web_page_preview": True
        }
        
        try:
            response = requests.post(url, json=payload, timeout=10)
            response.raise_for_status()
            return True
        except requests.exceptions.RequestException as e:
            print(f"❌ Telegram send failed: {e}")
            return False
    
    def send_volatility_alert(self, signal: Dict) -> bool:
        """Send alert when volatility triggers GPU"""
        
        emoji = "🚀" if signal['triggered'] else "📊"
        
        message = f"{emoji} <b>ARBITRAGE ALERT</b>\n\n"
        message += f"<b>Status:</b> {'GPU TRIGGERED ✅' if signal['triggered'] else 'Monitoring ⏸️'}\n"
        message += f"<b>Time:</b> {datetime.now().strftime('%H:%M:%S')}\n\n"
        
        message += f"<b>📊 Market Snapshot:</b>\n"
        message += f"• Opportunities: {signal['opportunity_count']}\n"
        message += f"• Best Spread: {signal['best_spread_pct']:.2f}%\n"
        message += f"• Potential Profit: €{signal['total_potential_profit_eur']:.2f}\n"
        message += f"• High Confidence: {signal['high_confidence_count']}\n\n"
        
        if signal['triggered'] and signal.get('details'):
            message += f"<b>🎯 Top Opportunities:</b>\n"
            for i, opp in enumerate(signal['details'][:3], 1):
                message += f"\n{i}. <b>{opp['token']}</b>\n"
                message += f"   • Spread: {opp['spread_pct']:.2f}%\n"
                message += f"   • Confidence: {opp['confidence_score']:.0%}\n"
                message += f"   • Route: {opp['buy_dex']} → {opp['sell_dex']}\n"
        else:
            message += f"<i>{signal['reason']}</i>"
        
        return self.send_message(message)
    
    def send_gpu_status(self, status: str, details: Optional[Dict] = None) -> bool:
        """Send GPU pod status update"""
        
        emoji_map = {
            "STARTING": "🔄",
            "RUNNING": "✅",
            "STOPPED": "⏸️",
            "ERROR": "❌"
        }
        
        emoji = emoji_map.get(status, "ℹ️")
        
        message = f"{emoji} <b>GPU STATUS UPDATE</b>\n\n"
        message += f"<b>Status:</b> {status}\n"
        message += f"<b>Time:</b> {datetime.now().strftime('%H:%M:%S')}\n"
        
        if details:
            if status == "RUNNING":
                message += f"\n<b>Runtime Details:</b>\n"
                message += f"• GPU: {details.get('gpu', 'Unknown')}\n"
                message += f"• Uptime: {details.get('uptime_hours', 0):.1f}h\n"
                message += f"• Cost: ${details.get('estimated_cost_usd', 0):.2f}\n"
            
            elif status == "ERROR":
                message += f"\n<b>Error:</b> {details.get('error', 'Unknown error')}"
        
        return self.send_message(message)
    
    def send_route_results(self, results: Dict) -> bool:
        """Send multi-hop route analysis results"""
        
        message = "🎯 <b>MULTI-HOP ROUTE ANALYSIS COMPLETE</b>\n\n"
        
        total_routes = sum(len(routes) for routes in results.get('routes', {}).values())
        message += f"<b>Total Routes Found:</b> {total_routes}\n\n"
        
        for hop_type, routes in results.get('routes', {}).items():
            if not routes:
                continue
            
            message += f"<b>{hop_type.upper()}:</b> {len(routes)} routes\n"
            
            # Show top 2 routes per type
            for i, route in enumerate(routes[:2], 1):
                profit = route.get('net_profit_pct', 0)
                confidence = route.get('confidence', 0)
                path = ' → '.join(route.get('path', []))
                
                message += f"  {i}. {profit:.2f}% profit | {confidence:.0%} conf\n"
                message += f"     {path}\n"
            
            message += "\n"
        
        message += f"<i>Full results saved to multihop_routes.json</i>"
        
        return self.send_message(message)
    
    def send_error(self, error_msg: str, context: str = "") -> bool:
        """Send error notification"""
        
        message = "❌ <b>ERROR ALERT</b>\n\n"
        
        if context:
            message += f"<b>Context:</b> {context}\n"
        
        message += f"<b>Error:</b> {error_msg}\n"
        message += f"<b>Time:</b> {datetime.now().strftime('%H:%M:%S')}"
        
        return self.send_message(message)
    
    def send_test_message(self) -> bool:
        """Send a test message to verify setup"""
        
        message = "✅ <b>Telegram Bot Connected</b>\n\n"
        message += "This is a test message from your arbitrage tracker.\n"
        message += f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
        message += "<i>Bot is ready to send alerts!</i>"
        
        return self.send_message(message)


def main():
    """Test Telegram notifier"""
    
    # Configuration
    BOT_TOKEN = "8469215299:AAG13gJXvEQk4CiFAE7v6wOZ3pOKHY-f-sk"
    CHAT_ID = "6314780875"
    
    notifier = TelegramNotifier(BOT_TOKEN, CHAT_ID)
    
    print("TELEGRAM NOTIFIER TEST")
    print("="*80)
    
    # Send test message
    print("\n1. Sending test message...")
    success = notifier.send_test_message()
    
    if success:
        print("✓ Test message sent! Check your Telegram.")
    else:
        print("❌ Failed to send test message")
        print("   Check bot token and chat ID")
    
    # Test volatility alert (example)
    print("\n2. Sending example volatility alert...")
    
    example_signal = {
        'triggered': True,
        'reason': 'Test alert',
        'opportunity_count': 3,
        'best_spread_pct': 1.25,
        'total_potential_profit_eur': 8.50,
        'high_confidence_count': 2,
        'timestamp': datetime.now().isoformat(),
        'details': [
            {
                'token': 'SOL',
                'spread_pct': 1.25,
                'confidence_score': 0.85,
                'buy_dex': 'Raydium',
                'sell_dex': 'Orca'
            }
        ]
    }
    
    success = notifier.send_volatility_alert(example_signal)
    
    if success:
        print("✓ Volatility alert sent!")
    else:
        print("❌ Failed to send volatility alert")
    
    print("\n" + "="*80)


if __name__ == "__main__":
    main()
